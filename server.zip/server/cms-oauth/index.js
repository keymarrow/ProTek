import 'dotenv/config';
import express from 'express';

// Uses global fetch (Node 18+). If on older Node, install 'node-fetch'.

const {
  PORT = 3001,
  GITHUB_CLIENT_ID,
  GITHUB_CLIENT_SECRET,
  BASE_URL, // e.g., https://protek.co.tz
  SCOPE = 'repo'
} = process.env;

if (!GITHUB_CLIENT_ID || !GITHUB_CLIENT_SECRET || !BASE_URL) {
  console.warn('[cms-oauth] Missing env vars: GITHUB_CLIENT_ID, GITHUB_CLIENT_SECRET, BASE_URL');
}

const app = express();

app.get('/api/health', (_req, res) => {
  res.json({ ok: true });
});

app.get('/api/auth', (req, res) => {
  const state = req.query.state || '';
  const redirectUri = `${BASE_URL}/api/auth/callback`;
  const url = new URL('https://github.com/login/oauth/authorize');
  url.searchParams.set('client_id', GITHUB_CLIENT_ID);
  url.searchParams.set('redirect_uri', redirectUri);
  url.searchParams.set('scope', SCOPE);
  if (state) url.searchParams.set('state', state);
  res.redirect(url.toString());
});

app.get('/api/auth/callback', async (req, res) => {
  const code = req.query.code;
  const state = req.query.state || '';
  if (!code) {
    return renderScript(res, 'error', { message: 'Missing code' });
  }
  try {
    const redirectUri = `${BASE_URL}/api/auth/callback`;
    const tokenResp = await fetch('https://github.com/login/oauth/access_token', {
      method: 'POST',
      headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' },
      body: JSON.stringify({
        client_id: GITHUB_CLIENT_ID,
        client_secret: GITHUB_CLIENT_SECRET,
        code,
        redirect_uri: redirectUri,
        state
      })
    });
    const data = await tokenResp.json();
    if (!data.access_token) {
      return renderScript(res, 'error', { message: 'No access_token', data });
    }
    return renderScript(res, 'success', { token: data.access_token });
  } catch (err) {
    return renderScript(res, 'error', { message: err?.message || String(err) });
  }
});

function renderScript(res, type, payload) {
  const channel = type === 'success' ? 'authorization:github:success' : 'authorization:github:error';
  const msg = `${channel}:${JSON.stringify(payload)}`;
  const html = `<!doctype html><html><body><script>
    (function(){
      try {
        window.opener && window.opener.postMessage(${JSON.stringify(msg)}, '*');
        window.close();
      } catch(e) { console.error(e); }
    })();
  </script></body></html>`;
  res.setHeader('Content-Type', 'text/html');
  res.send(html);
}

app.listen(PORT, () => {
  console.log(`[cms-oauth] Listening on :${PORT}`);
});
